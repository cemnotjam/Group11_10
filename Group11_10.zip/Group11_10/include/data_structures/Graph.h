#ifndef GRAPH_H
 #define GRAPH_H
 #include <string>
 #include "core/NodeData.h"
 enum RoadStatus { CLEAR, DAMAGED, BLOCKED };
 struct Vertex;  
 struct Edge {
    Vertex* to;
    int distance;
    RoadStatus status;
    Edge* next;
 };
 struct Vertex {
    std::string id;
    NodeData data; 
    Edge* edges;
    Vertex* next;
    bool visited; 
    int index;
 };
 class Graph {
 private:
    Vertex* head;
    bool dfs(Vertex* current, Vertex* target);
    bool dfsVisit(Vertex* current, Vertex* target);
    void resetVisited();
    int countVertices() const;
    void buildIndex(Vertex** arr, int n);
 public:
    Graph();
    ~Graph();
    void addVertex(const std::string& id);
    void addEdge(const std::string& from, const std::string& to,
                 int distance, RoadStatus status);
    Vertex* findVertex(const std::string& id);
    Vertex* getHead() const { return head; }
    bool updateRoadStatus(const std::string& from,
                      const std::string& to,
                      RoadStatus newStatus);
    bool isReachable(const std::string& from, const std::string& to);
    int shortestTravelTime(const std::string& from,
                           const std::string& to);
 };
 #endif
