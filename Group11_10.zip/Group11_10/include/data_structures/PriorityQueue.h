#ifndef PRIORITY_QUEUE_H
 #define PRIORITY_QUEUE_H
 struct PQNode {
    int priority;
    int value;
    PQNode* next;
 };
 class PriorityQueue {
 private:
    PQNode* head;
 public:
    PriorityQueue();
    ~PriorityQueue();
    void push(int priority, int value);
    int popMin();          // returns value with smallest priority
    bool isEmpty() const;
 };
 #endif
