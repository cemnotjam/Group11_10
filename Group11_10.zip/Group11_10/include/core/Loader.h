#pragma once
#include <string>

class Graph;

struct Truck {
    std::string id;
    int capacity = 0;
    std::string location;
    Truck* next = nullptr;
};

Truck* loadFromJson(const std::string& path, Graph& g);
void   freeTrucks(Truck* head);
