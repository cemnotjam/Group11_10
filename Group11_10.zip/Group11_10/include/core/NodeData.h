#pragma once
#include <string>

enum NodeType { WAREHOUSE, SHELTER, HOSPITAL };

struct Supplies {
    int water = 0;
    int food = 0;
    int medicine = 0;
};

struct NodeData {
    NodeType type;
    int population = 0;
    int days_without_supply = 0;
    bool critical = false;
    Supplies supplies; // sadece warehouse için dolu olacak
    Supplies need;   // shelters/hospitals için kalan ihtiyaç
    int urgency;     // cached

};
