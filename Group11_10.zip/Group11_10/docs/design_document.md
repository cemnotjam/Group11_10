# Design Document – PROJ-10 (Group11)
 ## 1.  Purpose
 This assignment simulates disaster logistics making plans.  Warehouses offer supplies (water/meals/medicine) to shelters and hospitals the use of vans.  The system hundreds a situation from JSON, computes travel instances below road constraints, generates transport plans, and reviews unmet demand.
 ---
 ## 2.  High-Level Architecture
 **Modules**
 - **Loader (core/Loader)**  
  Parses JSON enter and builds:
  - Graph vertices (nodes)
  - Graph edges (roads)
  - Linked listing of vehicles  
  Also initializes each demand node’s `need` and cached `urgency`.
 - **Graph (data_structures/Graph)**  
  Linked-listing adjacency illustration:
  - Vertex related list
  - Each vertex has adjacency facet list
  Provides:
  - `addVertex`, `addEdge`, `findVertex`
  - `shortestTravelTime(from, to)` (Dijkstra-based totally)
 - **PriorityQueue (data_structures/PriorityQueue)**  
  Custom precedence queue carried out with out STL.  Used by shortest direction.
 - **Planner (main.Cpp)**  
  Implements choice + transport loop:
  - Pick a target (safe haven/health facility) with maximum urgency
  - Pick a warehouse that may help and is closest to that target
  - Deliver greedily inside potential and inventory
  - Print `PLAN` strains
  - Print `UNMET` precis at the stop
 ---
 ## 3.  Data Model
 ### NodeData
 Each graph vertex stores:
 - `type`: WAREHOUSE / SHELTER / HOSPITAL
 - `population`
 - `days_without_supply`
 - `important` (hospitals)
 - `substances` (best significant for warehouses)
 - `need` (simplest significant for shelters/hospitals)
 - `urgency` (cached)
 ### Truck
 A truck is a node in a connected listing:
 - `identity`
 - `capability`
 - `area`
 - `subsequent`
 ---
 ## 4.  Assumptions / Rules
 ### Roads
 - Road fame is interpreted as:
  - **CLEAR**: regular tour fee
  - **DAMAGED**: travel cost is elevated (e.G., doubled)
  - **BLOCKED**: avenue can not be used
 - Roads are treated as **undirected** (added both guidelines).
 ### Need Initialization
 Demand nodes start with:
 - `water = population`
 - `meals  = populace`
 - `medicinal drug = populace` for hospitals
 - `medication = population / 10` for shelters
 ### Urgency (cached)
 urgency = populace × (1 + days_without_supply)
 if sanatorium and essential → urgency × 2
 ---
 ## 5.  Algorithms
 ### 5.1 Shortest Path (Modified Dijkstra)
 We compute the shortest tour time between nodes using a Dijkstra-style algorithm:
 - Each part’s price relies upon on its avenue reputation (CLEAR/DAMAGED/BLOCKED).
 - BLOCKED edges are skipped.
 - PriorityQueue helps extracting the minimum-distance next vertex.
 This is used again and again for:
 - Selecting goals (reachability)
 - Selecting excellent warehouse-to-goal route
 ### 5.2 Target Selection
 Among all shelters/hospitals that also have unmet demand:
 1.  Choose **maximum urgency**
 2.  Tie-ruin via **shortest journey time** from the truck’s current area
 3.  Tie-damage with the aid of **lexicographically smallest ID**
 ### five.Three Warehouse Selection
 For a particular target:
 - Consider warehouses that could supply at the least one of the goal’s last desires.
 - Choose the warehouse with **minimum tour time** to the target.
 - Tie-damage by means of lexicographically smallest ID.
 ### five.Four Delivery Strategy (Greedy, Persistent Update)
 For a delegated warehouse and goal, deliver within truck potential:
 1.  Medicine
 2.  Water
 three.  Food
 Delivery quantity is constrained by using:
 - final warehouse deliver
 - final goal need
 - remaining truck ability
 After delivery:
 - warehouse substances decrease
 - target desires lower
 - output prints delivered and remaining quantities
 ---
 ## 6.  Output Specification
 ### Plan line
 PLAN <truck_id> <warehouse_id> -> <target_id> time=<t>
 delivermed=x, water=y, meals=z remainingmed=a, water=b, food=c
 ### Unmet summary
 After planning ends:
 UNMET <node_id> med=a, water=b, food=c
 ---
 ## 7.  Testing Strategy
 We use unit tests to validate the core additives:
 - Graph production and basic conduct
 - PriorityQueue operations (push/popMin)
 - Shortest route correctness beneath street constraints
 `make check` runs all unit assessments.
 ---
 ## 8.  Limitations / Known Issues
 - Greedy transport isn't guaranteed globally most excellent.
 - Shortest route can be recomputed generally (overall performance alternate-off customary for readability).
 - Console output most effective (no graphical frontend until required by means of the instructor).
 - Road version assumes undirected edges.
 ---
 ## 9.  Future Improvements
 - Cache shortest paths from warehouses to all nodes to reduce repeated Dijkstra calls.
 - Add advanced worldwide making plans (multi-stop routes, higher allocation).
 - Extend reporting (total added consistent with truck, general unmet call for).