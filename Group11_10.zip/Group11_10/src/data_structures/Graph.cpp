#include "data_structures/Graph.h"
 #include <iostream>
 #include "data_structures/PriorityQueue.h"
 Graph::Graph() : head(nullptr) {}
 Graph::~Graph() {
    Vertex* v = head;
    while (v) {
        Edge* e = v->edges;
        while (e) {
            Edge* tmpE = e;
            e = e->next;
            delete tmpE;
        }
        Vertex* tmpV = v;
        v = v->next;
        delete tmpV;
    }
 }
 Vertex* Graph::findVertex(const std::string& id) {
    Vertex* curr = head;
    while (curr) {
        if (curr->id == id)
            return curr;
        curr = curr->next;
    }
    return nullptr;
 }
 void Graph::addVertex(const std::string& id) {
    if (findVertex(id)) return;
    Vertex* v = new Vertex;
    v->id = id;
    v->edges = nullptr;
    v->visited = false;   
    v->next = head;
    v->index = -1;
    head = v;
 }
 void Graph::addEdge(const std::string& from,
                    const std::string& to,
                    int distance,
                    RoadStatus status) {
    Vertex* vFrom = findVertex(from);
    Vertex* vTo   = findVertex(to);
    if (!  vFrom || !  vTo) {
        std::cerr << "Error: vertex not found\n";
        return;
    }
    Edge* e = new Edge;
    e->to = vTo;
    e->distance = distance;
    e->status = status;
    e->next = vFrom->edges;
    vFrom->edges = e;
 }
 bool Graph::updateRoadStatus(const std::string& from,
                             const std::string& to,
                             RoadStatus newStatus) {
    Vertex* vFrom = findVertex(from);
    Vertex* vTo   = findVertex(to);
    if (!  vFrom || !  vTo) return false;
    Edge* e = vFrom->edges;
    while (e) {
        if (e->to == vTo) {
            e->status = newStatus;
            return true;
        }
        e = e->next;
    }
    return false;
 }
 bool Graph::isReachable(const std::string& from,
                        const std::string& to) {
    Vertex* vFrom = findVertex(from);
    Vertex* vTo   = findVertex(to);
    if (!  vFrom || !  vTo) return false;
    resetVisited();
    return dfsVisit(vFrom, vTo);
 }
 bool Graph::dfsVisit(Vertex* current, Vertex* target) {
    if (current == target) return true;
    current->visited = true;
    Edge* e = current->edges;
    while (e) {
        if (e->status != BLOCKED) {
            Vertex* nextV = e->to;
            if (!  nextV->visited) {
                if (dfsVisit(nextV, target))
                    return true;
            }
        }
        e = e->next;
    }
    return false;
 }
 void Graph::resetVisited() {
    Vertex* v = head;
    while (v) {
        v->visited = false;
        v = v->next;
    }
 }
 int Graph::countVertices() const {
    int n = 0;
    Vertex* v = head;
    while (v) {
        ++n;
        v = v->next;
    }
    return n;
 }
 void Graph::buildIndex(Vertex** arr, int n) {
    Vertex* v = head;
    int i = 0;
    while (v && i < n) {
        v->index = i;
        arr[i] = v;
        v = v->next;
        ++i;
    }
 }
 static int roadCost(const Edge* e) {
    if (e->status == CLEAR)   return e->distance;
    if (e->status == DAMAGED) return e->distance * 2; // penalty
    return 1e9; // BLOCKED handled elsewhere
 }
 int Graph::shortestTravelTime(const std::string& from,
                              const std::string& to) {
    Vertex* s = findVertex(from);
    Vertex* t = findVertex(to);
    if (!  s || !  t) return -1;
    int n = countVertices();
    if (n <= 0) return -1;
    // Build mapping: index <-> Vertex*
    Vertex** verts = new Vertex*[n];
    buildIndex(verts, n);
    const int INF = 1000000000;
    int* dist = new int[n];
    bool* done = new bool[n];
    for (int i = 0; i < n; ++i) {
        dist[i] = INF;
        done[i] = false;
    }
    int sIdx = s->index;
    int tIdx = t->index;
    // Safety (in case something went wrong)
    if (sIdx < 0 || sIdx >= n || tIdx < 0 || tIdx >= n) {
        delete[] dist;
        delete[] done;
        delete[] verts;
        return -1;
    }
    // --- Dijkstra using your PriorityQueue ---
    // Your PQ stores (priority, value) where value is the vertex index.
    PriorityQueue pq;
    dist[sIdx] = 0;
    pq.push(0, sIdx);
    while (!  pq.isEmpty()) {
        int u = pq.popMin();      // gets the vertex index with smallest dist
        if (u < 0 || u >= n) continue;
        if (done[u]) continue;
        done[u] = true;
        if (u == tIdx) break; // early exit
        Vertex* vu = verts[u];
        Edge* e = vu->edges;
        while (e) {
            if (e->status != BLOCKED) {
                int v = e->to->index;
                int cost = roadCost(e);
                if (v >= 0 && v < n && dist[u] != INF) {
                    int nd = dist[u] + cost;
                    if (nd < dist[v]) {
                        dist[v] = nd;
                        pq.push(nd, v);
                    }
                }
            }
            e = e->next;
        }
    }
    int result = (dist[tIdx] == INF) ? -1 : dist[tIdx];
    delete[] dist;
    delete[] done;
    delete[] verts;
    return result;
 }
