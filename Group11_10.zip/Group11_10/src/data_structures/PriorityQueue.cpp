#include "data_structures/PriorityQueue.h"
 #include <iostream>
 PriorityQueue::PriorityQueue() : head(nullptr) {}
 PriorityQueue::~PriorityQueue() {
    while (head) {
        PQNode* tmp = head;
        head = head->next;
        delete tmp;
    }
 }
 bool PriorityQueue::isEmpty() const {
    return head == nullptr;
 }
 void PriorityQueue::push(int priority, int value) {
    PQNode* node = new PQNode{priority, value, nullptr};
    // insert at head if queue is empty or this is the new minimum
    if (!  head || priority < head->priority) {
        node->next = head;
        head = node;
        return;
    }
    // find insertion point
    PQNode* cur = head;
    while (cur->next && cur->next->priority <= priority) {
        cur = cur->next;
    }
    node->next = cur->next;
    cur->next = node;
 }
 int PriorityQueue::popMin() {
    if (!  head) {
        std::cerr << "Error: popMin on empty PriorityQueue\n";
        return -1; // or throw, but keep it simple for now
    }
    PQNode* tmp = head;
    int val = tmp->value;
    head = head->next;
    delete tmp;
    return val;
 }
