#include "core/Loader.h"
 #include "data_structures/Graph.h"
 #include "core/NodeData.h"
 #include <fstream>
 #include <iostream>
 #include <nlohmann/json.hpp>
 using json = nlohmann::json;
 static RoadStatus parseRoadStatus(const std::string& s) {
    if (s == "clear" || s == "CLEAR") return CLEAR;
    if (s == "damaged" || s == "DAMAGED") return DAMAGED;
    return BLOCKED;
 }
 static NodeType parseNodeType(const std::string& s) {
    if (s == "warehouse" || s == "WAREHOUSE") return WAREHOUSE;
    if (s == "shelter"   || s == "SHELTER")   return SHELTER;
    return HOSPITAL;
 }
 Truck* loadFromJson(const std::string& path, Graph& g) {
    std::ifstream in(path);
    if (!  in) {
        std::cerr << "Error: cannot open " << path << "\n";
        return nullptr;
    }
    json j;
    in >> j;
    // 1) NODES
    if (j.contains("nodes")) {
        for (const auto& node : j["nodes"]) {
            std::string id   = node["id"].get<std::string>();
            std::string type = node["type"].get<std::string>();
            g.addVertex(id);
            Vertex* v = g.findVertex(id);
            if (!  v) continue;
            v->data = NodeData{}; // reset all fields
            v->data.type = parseNodeType(type);
            // common fields
            if (node.contains("population"))
                v->data.population = node["population"].get<int>();
            if (node.contains("days_without_supply"))
                v->data.days_without_supply = node["days_without_supply"].get<int>();
            if (node.contains("critical"))
                v->data.critical = node["critical"].get<bool>();
            // warehouse supplies
            if (v->data.type == WAREHOUSE && node.contains("supplies")) {
                const auto& s = node["supplies"];
                if (s.contains("water"))    v->data.supplies.water    = s["water"].get<int>();
                if (s.contains("food"))     v->data.supplies.food     = s["food"].get<int>();
                if (s.contains("medicine")) v->data.supplies.medicine = s["medicine"].get<int>();
            }
            // shelter/hospital need + urgency initialization
            if (v->data.type == SHELTER || v->data.type == HOSPITAL) {
                v->data.need.water = v->data.population;
                v->data.need.food  = v->data.population;
                v->data.need.medicine =
                    (v->data.type == HOSPITAL) ?   v->data.population
                                               : (v->data.population / 10);
                int base = v->data.population * (1 + v->data.days_without_supply);
                if (v->data.type == HOSPITAL && v->data.critical)
                    base *= 2;
                v->data.urgency = base;
            } else {
                v->data.need = Supplies{};
                v->data.urgency = 0;
            }
        }
    }
    // 2) ROADS
    if (j.contains("roads")) {
        for (const auto& r : j["roads"]) {
            std::string from = r["from"].get<std::string>();
            std::string to   = r["to"].get<std::string>();
            int dist         = r["distance"].get<int>();
            std::string st   = r["status"].get<std::string>();
            RoadStatus rs = parseRoadStatus(st);
            // Roads treated as undirected
            g.addEdge(from, to, dist, rs);
            g.addEdge(to, from, dist, rs);
        }
    }
    // 3) TRUCKS (linked list)
    Truck* head = nullptr;
    if (j.contains("trucks")) {
        for (const auto& t : j["trucks"]) {
            Truck* tr = new Truck;
            tr->id       = t["id"].get<std::string>();
            tr->capacity = t["capacity"].get<int>();
            tr->location = t["location"].get<std::string>();
            tr->next     = head;
            head         = tr;
        }
    }
    return head;
 }
 void freeTrucks(Truck* head) {
    while (head) {
        Truck* tmp = head;
        head = head->next;
        delete tmp;
    }
 }
