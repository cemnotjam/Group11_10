#include <iostream>
 #include <fstream>
 #include <string>
 #include <algorithm>
 #include "core/NodeData.h"
 #include "data_structures/Graph.h"
 #include "core/Loader.h"
 // Demo txt input için
 static RoadStatus parseStatus(const std::string& s) {
    if (s == "CLEAR") return CLEAR;
    if (s == "DAMAGED") return DAMAGED;
    if (s == "BLOCKED") return BLOCKED;
    return CLEAR;
 }
 static bool endsWith(const std::string& s, const std::string& suffix) {
    if (s.size() < suffix.size()) return false;
    return s.compare(s.size() - suffix.size(), suffix.size(), suffix) == 0;
 }
 static bool isDemandNode(NodeType t) {
    return (t == SHELTER || t == HOSPITAL);
 }
 static bool hasAnyNeed(const NodeData& d) {
    return d.need.water > 0 || d.need.food > 0 || d.need.medicine > 0;
 }
 static int min3(int a, int b, int c) {
    return std::min(a, std::min(b, c));
 }
 static bool warehouseCanHelpTarget(const NodeData& wh, const NodeData& target) {
    if (target.need.medicine > 0 && wh.supplies.medicine > 0) return true;
    if (target.need.water    > 0 && wh.supplies.water    > 0) return true;
    if (target.need.food     > 0 && wh.supplies.food     > 0) return true;
    return false;
 }

 static Vertex* pickBestTarget(Graph& g, const std::string& from, int& outTime) {
    Vertex* best = nullptr;
    int bestScore = -1;
    int bestTime = -1;
    for (Vertex* v = g.getHead(); v; v = v->next) {
        if (! isDemandNode(v->data.type)) continue;
        if (! hasAnyNeed(v->data)) continue;
        int time = g.shortestTravelTime(from, v->id);
        if (time == -1) continue;
        int score = v->data.urgency;
        if (! best ||
            score > bestScore ||
            (score == bestScore && time < bestTime) ||
            (score == bestScore && time == bestTime && v->id < best->id)) {
            best = v;
            bestScore = score;
            bestTime = time;
        }
    }
    outTime = best ?  bestTime : -1;
    return best;
 }
 // Target'a en kısa sürede ulaşan, iş görebilen warehouse'ı seç
 static Vertex* pickBestWarehouse(Graph& g, Vertex* targetV, int& outTime) {
    if (! targetV) { outTime = -1; return nullptr; }
    Vertex* best = nullptr;
    int bestTime = -1;
    for (Vertex* v = g.getHead(); v; v = v->next) {
        if (v->data.type != WAREHOUSE) continue;
        if (! warehouseCanHelpTarget(v->data, targetV->data)) continue;
        int time = g.shortestTravelTime(v->id, targetV->id);
        if (time == -1) continue;
        if (! best || time < bestTime || (time == bestTime && v->id < best->id)) {
            best = v;
            bestTime = time;
        }
    }
    outTime = best ?  bestTime : -1;
    return best;
 }
 // Teslimat: need ve supplies persistent günceller (greedy)
 static void deliverGreedyPersistent(
    NodeData& warehouse,
    NodeData& target,
    int cap,
    int& dMed, int& dWater, int& dFood
 ) {
    dMed = dWater = dFood = 0;
    if (cap > 0) {
        int take = min3(warehouse.supplies.medicine, target.need.medicine, cap);
        dMed += take;
        warehouse.supplies.medicine -= take;
        target.need.medicine -= take;
        cap -= take;
    }
    if (cap > 0) {
        int take = min3(warehouse.supplies.water, target.need.water, cap);
        dWater += take;
        warehouse.supplies.water -= take;
        target.need.water -= take;
        cap -= take;
    }
    if (cap > 0) {
        int take = min3(warehouse.supplies.food, target.need.food, cap);
        dFood += take;
        warehouse.supplies.food -= take;
        target.need.food -= take;
        cap -= take;
    }
 }
 // Demand node unreachable mı?  
 static bool isReachableFromAnyWarehouse(Graph& g, Vertex* targetV) {
    if (! targetV) return false;
    for (Vertex* v = g.getHead(); v; v = v->next) {
        if (v->data.type != WAREHOUSE) continue;
        if (g.shortestTravelTime(v->id, targetV->id) != -1) return true;
    }
    return false;
 }
 int main(int argc, char** argv) {
    std::string path = (argc >= 2) ?  argv[1] : "data/demo.txt";
    Graph g;
    Truck* trucks = nullptr;

    if (endsWith(path, ".json")) {
        trucks = loadFromJson(path, g);
        if (! trucks) {
            std::cerr << "Error: failed to load JSON (or no trucks)\n";
            return 1;
        }
        // (A) Unreachable demand node raporu (isteğe bağlı ama iyi)
        for (Vertex* d = g.getHead(); d; d = d->next) {
            if (! isDemandNode(d->data.type)) continue;
            if (! hasAnyNeed(d->data)) continue; // ihtiyacı yoksa raporlama
            if (! isReachableFromAnyWarehouse(g, d)) {
                std::cout << "UNREACHABLE " << d->id << "\n";
            }
        }
        // (B) Multi-truck planlama
        for (Truck* tr = trucks; tr; tr = tr->next) {
            while (true) {
                int targetTime = -1;
                Vertex* targetV = pickBestTarget(g, tr->location, targetTime);
                if (! targetV) {
                    std::cout << "DONE " << tr->id << ": no reachable unmet demand\n";
                    break;
                }
                int whToTargetTime = -1;
                Vertex* whV = pickBestWarehouse(g, targetV, whToTargetTime);
                if (! whV) {
                    break;
                }
                int dMed, dWater, dFood;
                deliverGreedyPersistent(whV->data, targetV->data, tr->capacity, dMed, dWater, dFood);
                if (dMed + dWater + dFood == 0) {
                    // Teoride olmamalı; yine de emniyet
                    std::cout << "DONE " << tr->id << ": could not deliver anything\n";
                    break;
                }
                std::cout << "PLAN " << tr->id << " " << whV->id << " -> " << targetV->id
                          << " time=" << whToTargetTime
                          << " deliver{med=" << dMed << ", water=" << dWater << ", food=" << dFood << "}"
                          << " remaining{med=" << targetV->data.need.medicine
                          << ", water=" << targetV->data.need.water
                          << ", food=" << targetV->data.need.food << "}"
                          << "\n";
                // Basit model: truck bir sonraki iterasyona seçilen warehouse'da başlasın
                tr->location = whV->id;
            }
        }

        // Final unmet summary
        for (Vertex* v = g.getHead(); v; v = v->next) {
            if (!( v->data.type == SHELTER || v->data.type == HOSPITAL)) continue;
            if (v->data.need.medicine == 0 &&
                v->data.need.water == 0 &&
                v->data.need.food == 0) continue;
            std::cout << "UNMET " << v->id
                    << " {med=" << v->data.need.medicine
                    << ", water=" << v->data.need.water
                    << ", food=" << v->data.need.food << "}\n";
        }
        freeTrucks(trucks);
        return 0;
    }
    // 2) JSON değilse demo format parse et
    std::ifstream in(path);
    if (! in) {
        std::cerr << "Error: cannot open " << path << "\n";
        return 1;
    }
    std::cout << "OK: opened " << path << "\n";
    std::string type;
    while (in >> type) {
        if (type == "VERTEX") {
            std::string id;
            in >> id;
            g.addVertex(id);
        } else if (type == "EDGE") {
            std::string from, to, statusStr;
            int dist;
            in >> from >> to >> dist >> statusStr;
            g.addEdge(from, to, dist, parseStatus(statusStr));
        } else if (type == "QUERY") {
            std::string from, to;
            in >> from >> to;
            int t = g.shortestTravelTime(from, to);
            if (t == -1)
                std::cout << "UNREACHABLE: " << from << " -> " << to << "\n";
            else
                std::cout << "Shortest travel time " << from << " -> " << to << " = " << t << "\n";
        } else {
            std::string rest;
            std::getline(in, rest);
        }
    }
    return 0;
 }
