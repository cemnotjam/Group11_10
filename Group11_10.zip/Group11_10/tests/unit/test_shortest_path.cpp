#include "data_structures/Graph.h"
 #include <iostream>
 int main() {
    Graph g;
    g.addVertex("A");
    g.addVertex("B");
    g.addVertex("C");
    // Two routes A->B directly (10) vs A->C->B (3+3=6)
    g.addEdge("A", "B", 10, CLEAR);
    g.addEdge("A", "C", 3, CLEAR);
    g.addEdge("C", "B", 3, CLEAR);
    int d1 = g.shortestTravelTime("A", "B");
    if (d1 != 6) {
        std::cerr << "[FAIL] expected 6, got " << d1 << "\n";
        return 1;
    }
    // Block the cheap route
    g.updateRoadStatus("C", "B", BLOCKED);
    int d2 = g.shortestTravelTime("A", "B");
    if (d2 != 10) {
        std::cerr << "[FAIL] expected 10, got " << d2 << "\n";
        return 1;
    }
    // Make direct road damaged: 10*2=20, reopen cheap route: back to 6
    g.updateRoadStatus("C", "B", CLEAR);
    g.updateRoadStatus("A", "B", DAMAGED);
    int d3 = g.shortestTravelTime("A", "B");
    if (d3 != 6) {
        std::cerr << "[FAIL] expected 6, got " << d3 << "\n";
        return 1;
    }
    std::cout << "[OK] shortest path test passed\n";
    return 0;
 }
