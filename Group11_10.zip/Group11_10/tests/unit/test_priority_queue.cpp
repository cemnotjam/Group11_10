#include "data_structures/PriorityQueue.h"
 #include <iostream>
 int main() {
    PriorityQueue pq;
    // push(priority, value)
    // priority = distance/cost, value = vertex/id
    pq.push(50, 1);
    pq.push(30, 2);
    pq.push(40, 3);
    pq.push(10, 4);
    int a = pq.popMin();
    if (a != 4) {
        std::cerr << "[FAIL] Expected popMin() = 4, got " << a << "\n";
        return 1;
    }
    int b = pq.popMin();
    if (b != 2) {
        std::cerr << "[FAIL] Expected popMin() = 2, got " << b << "\n";
        return 1;
    }
    int c = pq.popMin();
    if (c != 3) {
        std::cerr << "[FAIL] Expected popMin() = 3, got " << c << "\n";
        return 1;
    }
    int d = pq.popMin();
    if (d != 1) {
        std::cerr << "[FAIL] Expected popMin() = 1, got " << d << "\n";
        return 1;
    }
    if (!pq.isEmpty()) {
        std::cerr << "[FAIL] Queue should be empty\n";
        return 1;
    }
    std::cout << "[OK] PriorityQueue test passed\n";
    return 0;
 }
