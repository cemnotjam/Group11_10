#include "data_structures/Graph.h"
 #include <iostream>
 int main() {
    Graph g;
    g.addVertex("A");
    g.addVertex("B");
    if (!  g.findVertex("A") || !  g.findVertex("B")) {
        std::cerr << "[FAIL] Vertex creation failed\n";
        return 1;
    }
    g.addEdge("A", "B", 10, CLEAR);
    Vertex* a = g.findVertex("A");
    if (!  a || !  a->edges) {
        std::cerr << "[FAIL] Edge creation failed\n";
        return 1;
    }
    if (a->edges->to != g.findVertex("B")) {
        std::cerr << "[FAIL] Edge points to wrong vertex\n";
        return 1;
    }
    Vertex* b = g.findVertex("B");
    if (a->edges->to != b) { /* fail */ }
    if (!  g.isReachable("A", "B")) {
        std::cerr << "[FAIL] A should reach B\n";
        return 1;
    }
    if (!  g.updateRoadStatus("A", "B", BLOCKED)) {
        std::cerr << "[FAIL] updateRoadStatus failed\n";
        return 1;
    }
    if (g.isReachable("A", "B")) {
        std::cerr << "[FAIL] A should NOT reach B after blocking\n";
        return 1;
    }
    std::cout << "[OK] Graph basic test passed\n";
    return 0;
 }
